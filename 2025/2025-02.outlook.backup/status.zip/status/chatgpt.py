import os
import sys
from datetime import datetime, timedelta

def validate_year(year):
    try:
        year = int(year)
        if year < 1000 or year > 9999:
            raise ValueError("Year must be a four-digit number (YYYY).")
        return year
    except ValueError as e:
        print(f"Error: {e}")
        sys.exit(1)

def create_directory(path):
    os.makedirs(path, exist_ok=True)

def generate_html(file_path, title, links):
    content = f"""<!DOCTYPE html>
<html>
<head>
    <title>{title}</title>
</head>
<body>
    <h1>{title}</h1>
    <ul>
        {''.join([f'<li><a href="{link}">{desc}</a></li>' for desc, link in links.items()])}
    </ul>
</body>
</html>"""
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def generate_structure(year, current_location):
    year = validate_year(year)
    base_path = os.path.join(current_location, str(year))
    create_directory(base_path)
    
    # Generate Year HTML
    year_links = {
        "Previous Year": f"../{year-1}/{current_location}.{year-1}.html",
        "Next Year": f"../{year+1}/{current_location}.{year+1}.html"
    }
    for month in range(1, 13):
        year_links[f"Month {month:02d}"] = f"{month:02d}/{current_location}.{year}-{month:02d}.html"
    
    generate_html(os.path.join(base_path, f"{current_location}.{year}.html"), f"{current_location} {year}", year_links)
    
    # Generate Month Directories & HTML
    for month in range(1, 13):
        month_path = os.path.join(base_path, f"{month:02d}")
        create_directory(month_path)
        month_links = {
            "Previous Month": f"../{(month-1):02d}/{current_location}.{year}-{(month-1):02d}.html" if month > 1 else "../{year-1}/12/{current_location}.{year-1}-12.html",
            "Next Month": f"../{(month+1):02d}/{current_location}.{year}-{(month+1):02d}.html" if month < 12 else f"../{year+1}/01/{current_location}.{year+1}-01.html",
            "Year Index": f"../{current_location}.{year}.html"
        }
        days_in_month = (datetime(year, month % 12 + 1, 1) - timedelta(days=1)).day
        for day in range(1, days_in_month + 1):
            month_links[f"Day {day:02d}"] = f"{day:02d}/{current_location}.{year}-{month:02d}-{day:02d}.html"
        
        generate_html(os.path.join(month_path, f"{current_location}.{year}-{month:02d}.html"), f"{current_location} {year}-{month:02d}", month_links)
        
        # Generate Day Directories & HTML
        for day in range(1, days_in_month + 1):
            day_path = os.path.join(month_path, f"{day:02d}")
            create_directory(day_path)
            day_links = {
                "Previous Day": f"../{(day-1):02d}/{current_location}.{year}-{month:02d}-{(day-1):02d}.html" if day > 1 else f"../{(month-1):02d}/{datetime(year, month-1 if month > 1 else 12, 1).day}/{current_location}.{year}-{month-1:02d}-{datetime(year, month-1 if month > 1 else 12, 1).day}.html",
                "Next Day": f"../{(day+1):02d}/{current_location}.{year}-{month:02d}-{(day+1):02d}.html" if day < days_in_month else f"../{(month+1):02d}/01/{current_location}.{year}-{month+1:02d}-01.html",
                "Month Index": f"../{current_location}.{year}-{month:02d}.html"
            }
            for hour in range(24):
                day_links[f"Hour {hour:02d}"] = f"{hour:02d}/{current_location}.{year}-{month:02d}-{day:02d}.{hour:02d}.html"
            
            generate_html(os.path.join(day_path, f"{current_location}.{year}-{month:02d}-{day:02d}.html"), f"{current_location} {year}-{month:02d}-{day:02d}", day_links)
            
            # Generate Hour Directories & HTML
            for hour in range(24):
                hour_path = os.path.join(day_path, f"{hour:02d}")
                create_directory(hour_path)
                hour_links = {
                    "Previous Hour": f"../{(hour-1):02d}/{current_location}.{year}-{month:02d}-{day:02d}.{(hour-1):02d}.html" if hour > 0 else f"../{(day-1):02d}/23/{current_location}.{year}-{month:02d}-{day-1:02d}.23.html",
                    "Next Hour": f"../{(hour+1):02d}/{current_location}.{year}-{month:02d}-{day:02d}.{(hour+1):02d}.html" if hour < 23 else f"../{(day+1):02d}/00/{current_location}.{year}-{month:02d}-{day+1:02d}.00.html",
                    "Day Index": f"../{current_location}.{year}-{month:02d}-{day:02d}.html"
                }
                for minute in range(0, 60, 10):
                    hour_links[f"Minute {minute:02d}"] = f"{minute:02d}/{current_location}.{year}-{month:02d}-{day:02d}.{hour:02d}-{minute:02d}.html"
                
                generate_html(os.path.join(hour_path, f"{current_location}.{year}-{month:02d}-{day:02d}.{hour:02d}.html"), f"{current_location} {year}-{month:02d}-{day:02d} {hour:02d}:00", hour_links)
    
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python generate_structure.py <year> <current_location>")
        sys.exit(1)
    generate_structure(sys.argv[1], sys.argv[2])
