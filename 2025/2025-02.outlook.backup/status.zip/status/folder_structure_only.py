import os
from datetime import datetime, timedelta

def create_folder_structure(client_location: str, year: int):
    base_path = os.path.abspath(client_location)
    os.makedirs(base_path, exist_ok=True)
    
    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)
    
    current_date = start_date
    while current_date <= end_date:
        year_str = f"{current_date.year}"
        month_str = f"{current_date.month:02d}"
        day_str = f"{current_date.day:02d}"
        
        day_path = os.path.join(base_path, year_str, month_str, day_str)
        os.makedirs(day_path, exist_ok=True)
        
        for hour in range(24):
            hour_str = f"{hour:02d}"
            hour_path = os.path.join(day_path, hour_str)
            os.makedirs(hour_path, exist_ok=True)
            
            for minute in range(0, 60, 10):
                minute_str = f"{minute:02d}"
                minute_path = os.path.join(hour_path, minute_str)
                os.makedirs(minute_path, exist_ok=True)
                
                file_name = f"{client_location}.{year_str}-{month_str}-{day_str}.{hour_str}-{minute_str}.html"
                file_path = os.path.join(minute_path, file_name)
                with open(file_path, "w") as file:
                    file.write(f"<html><head><title>{file_name}</title></head><body><h1>{file_name}</h1></body></html>")
        
        current_date += timedelta(days=1)

if __name__ == "__main__":
    client_location = input("Enter client location prefix: ")
    year = int(input("Enter year: "))
    create_folder_structure(client_location, year)
    print("Folder structure and files created successfully!")
